
public enum Role {
	ADMIN,
	CUSTOMER,
}
