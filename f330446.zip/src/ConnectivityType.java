import java.lang.Enum;

public enum ConnectivityType {
    WIRED,
    WIRELESS;
	

}
