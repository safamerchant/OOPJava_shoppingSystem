import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StockFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private DefaultTableModel model;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				StockFrame frame = new StockFrame();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public StockFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 948, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout());

		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);

		table = new JTable();
		scrollPane.setViewportView(table);

		String[] columnHeaders = {"Barcode", "Category", "Device Type", "Brand",  "Colour","Connectivity", "Quantity", "Original Price", "Retail Price", "Additional Info"};
		model = new DefaultTableModel(columnHeaders, 0);
		table.setModel(model);

		JLabel lblNewLabel = new JLabel("Stock List");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 27));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblNewLabel, BorderLayout.NORTH);

		// Call method to populate the table with data from the Stock.txt file
		populateTable();

		// Button panel for "Save Changes" and "Add Entry"
		JPanel buttonPanel = new JPanel();
		contentPane.add(buttonPanel, BorderLayout.SOUTH);

		// Save Changes button
		JButton btnSaveChanges = new JButton("Save Changes");
		btnSaveChanges.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				saveChangesToFile();
			}
		});
		
		JButton LogoutBtn = new JButton("Log Out");
		buttonPanel.add(LogoutBtn);
		buttonPanel.add(btnSaveChanges);
		
		//Logout function:
        LogoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Show a confirmation dialog
                int option = JOptionPane.showConfirmDialog(StockFrame.this, "Are you sure you want to log out", "Confirm Logout", JOptionPane.YES_NO_OPTION);
                
                // Check the user's choice
                if (option == JOptionPane.YES_OPTION) {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            // Show the message dialog
                            JOptionPane.showMessageDialog(StockFrame.this, "Logging Out....", "Logout", JOptionPane.INFORMATION_MESSAGE);
                            // Restart the application from MainFrame
                            MainFrame mainFrame = new MainFrame();
                            mainFrame.setVisible(true);
                            dispose();
                        }
                    });
                }
            }
        });

		// Add Entry button
		JButton btnAddEntry = new JButton("Add Entry");
		btnAddEntry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AddEntryFrame addEntryFrame = new AddEntryFrame(StockFrame.this); // Pass the StockFrame instance
				addEntryFrame.setVisible(true);
			}
		});
		buttonPanel.add(btnAddEntry);
	}


    private void populateTable() {
        List<ShopProduct> productList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("Stock.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                ShopProduct product = ShopProduct.createProduct(line);
                if (product != null) {
                    productList.add(product);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Sort the product list based on retail price in ascending order
        productList.sort(Comparator.comparingDouble(ShopProduct::getRetailPrice));

        // Add sorted products to the table model
        for (ShopProduct product : productList) {
            Object[] rowData = {
            		product.getBarcode(),
					product.getCategory(),
					product.getdeviceType(),
					product.getBrand(),
					product.getColor(),
					product.getConnectivity(),
					product.getQuantityInStock(),
					product.getOriginalCost(),
					product.getRetailPrice(),
					product.getAdditionalInfo()
            };
            model.addRow(rowData);
        }
    }
	

	private void saveChangesToFile() {
		try (FileWriter writer = new FileWriter("Stock.txt")) {
			for (int i = 0; i < model.getRowCount(); i++) {
				for (int j = 0; j < model.getColumnCount(); j++) {
					writer.write(model.getValueAt(i, j).toString());
					if (j < model.getColumnCount() - 1) {
						writer.write(", ");
					}
				}
				// Add a newline character if it's not the last row
				if (i < model.getRowCount() - 1) {
					writer.write("\n");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public JTable getTable() {
	    return table; // Assuming 'table' is the instance variable representing your table
	}

	public void addNewEntry(String[] entry) {
	    // Assuming entry contains data in the format of StockProduct class attributes
	    // Extract data from entry array
	    int barcode = Integer.parseInt(entry[0]);
	    String brand = entry[1];
	    String color = entry[2];
	    DeviceType deviceType = DeviceType.valueOf(entry[3]); // Assuming DeviceType is an enum
	    ConnectivityType connectivity = ConnectivityType.valueOf(entry[4]); // Assuming ConnectivityType is an enum
	    int quantityInStock = Integer.parseInt(entry[5]);
	    double originalCost = Double.parseDouble(entry[6]);
	    double retailPrice = Double.parseDouble(entry[7]);
	    ProductCategory category = ProductCategory.valueOf(entry[8]); // Assuming ProductCategory is an enum
	    String additionalInfo = entry[9];

	    // Create a new StockProduct object with the extracted data
	    StockProduct newProduct = new StockProduct(barcode, category, deviceType, brand, color, connectivity,
	            quantityInStock, originalCost, retailPrice, additionalInfo);

	    // Add the new StockProduct object to the table
	    Object[] rowData = {
	            newProduct.getBarcode(),
	            newProduct.getCategory(),
	            newProduct.getdeviceType(),
	            newProduct.getBrand(),
	            newProduct.getColor(),
	            newProduct.getConnectivity(),
	            newProduct.getQuantityInStock(),
	            newProduct.getOriginalCost(),
	            newProduct.getRetailPrice(),
	            newProduct.getAdditionalInfo()
	    };
	    model.addRow(rowData);
	}

}
