import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// Abstract class representing a product: In this abstract class the Product class is instantiated by scanning the Stock.txt, output shown via GUI.
public abstract class Product {
    // Attributes
    protected int barcode; // Product barcode
    protected ProductCategory category; // Category of the product
    protected String brand; // Product brand
    protected String color; // Product color
    protected ConnectivityType connectivity; // Type of connectivity
    protected int quantityInStock; // Quantity of product in stock
    protected double originalCost; // Original cost of the product
    protected double retailPrice; // Retail price of the product
    

    // Constructor
    public Product(int barcode, ProductCategory category, String brand, String color, ConnectivityType connectivity,
                   int quantityInStock, double originalCost, double retailPrice ) {
        this.barcode = barcode;
        this.category = category;
        this.brand = brand;
        this.color = color;
        this.connectivity = connectivity;
        this.quantityInStock = quantityInStock;
        this.originalCost = originalCost;
        this.retailPrice = retailPrice;
        
    }

    // Abstract method to be implemented by subclasses
    // toString method in Product class
    @Override
    public abstract String toString();
    // Main method


    // Getters and setters:
    public int getBarcode() {
        return barcode;
    }
    public void setBarcode(int barcode) {
        this.barcode = barcode;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public ConnectivityType getConnectivity() {
        return connectivity;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }
    public void setQuantityInStock(int quantityInStock) {
        this.quantityInStock = quantityInStock;
    }
    public double getOriginalCost() {
        return originalCost;
    }
    public void setOriginalCost(double originalCost) {
        this.originalCost = originalCost;
    }
    public double getRetailPrice() {
        return retailPrice;
    }
    public void setRetailPrice(double retailPrice) {
        this.retailPrice = retailPrice;
    }
    public ProductCategory getCategory() {
        return category;
    }

    
}
