import java.lang.Enum;


public enum DeviceType {
	GAMING,
	STANDARD,
	FLEXIBLE
}
