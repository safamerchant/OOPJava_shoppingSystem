import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


//To Do:
//	-fix the add back to cudtomerframe table when logout at BasketFrame (function restoreStockQuantity)
//	-fix the issue of not removing products from basket(do before lab)
//	- fix the card number and details to do with the spec
//	-fix the commenting
//	-complete the UML class diagram
//	-put it onto the web remote thing

public class MainFrame extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainFrame frame = new MainFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    public void restartApplication() {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainFrame frame = new MainFrame();
                    frame.setVisible(true);
                    dispose(); // Close the current PaymentFrame
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public MainFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 568, 331);
        setResizable(false);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(29, 163, 139)); // Darker blue background
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

     // Light blue column
        JPanel blackPanel = new JPanel();
        blackPanel.setBackground(new Color(0, 0, 0)); // Light blue color
        blackPanel.setBounds(0, 0, 174, 296); // Full height, 120 width
        contentPane.add(blackPanel);

        try {
            ImageIcon imageIcon = new ImageIcon("icon.png");
            Image image = imageIcon.getImage(); // Get the image
            Image newImage = image.getScaledInstance(100, 100, Image.SCALE_SMOOTH); // Resize the image
            ImageIcon resizedIcon = new ImageIcon(newImage); // Create a new ImageIcon with the resized image

            JLabel imageLabel = new JLabel(resizedIcon); // Create the label with the resized image
            imageLabel.setBounds(35, 10, 100, 100); // Adjust position and size as needed
            blackPanel.add(imageLabel, BorderLayout.NORTH); // Add the label to the panel
        } catch (Exception e) {
            e.printStackTrace();
        }
        
     // Add "WELCOME TO THE TECH SHOP" text
        JLabel welcomeLabel = new JLabel("<html><center>WELCOME TO THE TECH SHOP</center></html>");
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Georgia", Font.BOLD, 16));
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setVerticalAlignment(SwingConstants.CENTER); // Center vertically
        welcomeLabel.setOpaque(false); // Make label transparent to show background
        welcomeLabel.setBorder(new EmptyBorder(20, 0, 0, 0)); // Add some padding to move it down
        blackPanel.add(welcomeLabel, BorderLayout.NORTH);


        blackPanel.setLayout(new BorderLayout()); // Set BorderLayout for bluePanel
        blackPanel.add(welcomeLabel, BorderLayout.CENTER);

        // Adjusting the position of welcomeLabel
        welcomeLabel.setBounds(0, 120, 174, 100); // Adjust position and size as needed

        // Add "LOGIN" text on the dark blue left side
        JLabel loginLabel = new JLabel("LOGIN");
        loginLabel.setForeground(Color.WHITE);
        loginLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
        loginLabel.setBounds(304, 19, 100, 30);
        contentPane.add(loginLabel);

        // Pre-existing buttons with cream background and hover effect
        JButton btn1 = createButton("User 1", 300, 80);
        JButton btn2 = createButton("User 2", 300, 120);
        JButton btn3 = createButton("User 3", 300, 160);
        JButton btn4 = createButton("User 4", 300, 200);
        
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userDetails = User.getUserDetails("user1");
                String fullAddress = User.getFullAddress("user1");
                System.out.println(fullAddress);
                if (userDetails != null) {
                	roleFrameChange(userDetails, fullAddress);  // Navigate based on user's role
//                    System.out.println(userDetails); // Output user details
                } else {
                    System.out.println("User not found");
                }
            }
        });
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userDetails = User.getUserDetails("user2");
                String fullAddress = User.getFullAddress("user2");
                System.out.println(fullAddress);
                if (userDetails != null) {
                	roleFrameChange(userDetails, fullAddress); // Navigate based on user's role
//                    System.out.println(userDetails); // Output user details
                } else {
                    System.out.println("User not found");
                }
            }
        });
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userDetails = User.getUserDetails("user3");
                String fullAddress = User.getFullAddress("user3");
                System.out.println(fullAddress);
                if (userDetails != null) {
                	roleFrameChange(userDetails, fullAddress);  // Navigate based on user's role
//                    System.out.println(userDetails); // Output user details
                } else {
                    System.out.println("User not found");
                }
            }
        });
        btn4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userDetails = User.getUserDetails("user4");
                String fullAddress = User.getFullAddress("user4");
                System.out.println(fullAddress);
                if (userDetails != null) {
                	roleFrameChange(userDetails, fullAddress); // Navigate based on user's role
//                    System.out.println(userDetails); // Output user details
                } else {
                    System.out.println("User not found");
                }
            }
        });
    }
    

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBackground(new Color(255, 255, 255)); // Cream colour
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Tahoma", Font.PLAIN, 13));
        button.setFocusPainted(false); // Remove the focus border
        button.setContentAreaFilled(false); // Remove the default background
        button.setOpaque(true); // Make the button opaque for custom painting
        button.setBounds(x, y, 110, 30); // Adjusted x and y coordinates
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(173, 216, 230)); // Light blue colour on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(255, 255, 255)); // Restore original cream colour on exit
            }
        });
        contentPane.add(button);
        return button; // Return the created JButton
    }
    private void roleFrameChange(String userDetails, String fullAddress) {
        String role = userDetails; // Extract the user's role
        if (role != null) {
            switch (role.toUpperCase()) {
            
                case "ADMIN":
                    // Open StockFrame
                    StockFrame stockFrame = new StockFrame();
                    stockFrame.setVisible(true);
                    break;
                case "CUSTOMER":
                    // Open CustomerFrame
                	// Get the full address from the User class
                    CustomerFrame customerFrame = new CustomerFrame(fullAddress);
                    customerFrame.setVisible(true);
                    break;
                default:
                    // Handle invalid user role
                    System.out.println("Invalid user role");
                    break;
            }
        } else {
            // Handle null user role
//        	System.out.println(userDetails);
            System.out.println("User role not found");
        }
    }

}
