import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.swing.border.LineBorder;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BasketFrame extends JFrame {

    private JPanel contentPane;
    private DefaultTableModel model;

    public BasketFrame(List<ShopProduct> basket, JTable table, String fullAddress) {
    	JTable finalTable = table;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 600);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(29, 163, 139));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        

        // Create an instance of CustomerFrame if it's null
        if (CustomerFrame.frame == null) {
            CustomerFrame.frame = new CustomerFrame(fullAddress);
        }

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(237, 87, 741, 407);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        String[] columnHeaders = {"Barcode","Category","Device Type", "Brand", "Color", "Connectivity", "Quantity", "Retail Price",  "Additional Info"};
        model = new DefaultTableModel(columnHeaders, 0);
        table.setModel(model);
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.BLACK);
        panel.setBounds(0, 0, 227, 565);
        contentPane.add(panel);
        
        JToggleButton LogoutBtn = new JToggleButton("LOGOUT");
        LogoutBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        LogoutBtn.setBackground(Color.WHITE);
        LogoutBtn.setBounds(20, 332, 184, 46);
        panel.add(LogoutBtn);
        
      //Logout function:
        LogoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Show a confirmation dialog
                int option = JOptionPane.showConfirmDialog(BasketFrame.this, "Are you sure you want to log out, basket will be cleared?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
                
                // Check the user's choice
                if (option == JOptionPane.YES_OPTION) {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            // Show the message dialog
                            JOptionPane.showMessageDialog(BasketFrame.this, "Logged out successfully.", "Logout", JOptionPane.INFORMATION_MESSAGE);
                            restoreStockQuantity(basket, finalTable);
                            basket.clear();
                            // Restart the application from MainFrame
                            MainFrame mainFrame = new MainFrame();
                            mainFrame.setVisible(true);
                            
                            // Close the current PaymentFrame
                            dispose();
                        }
                    });
                }
            }
        });
        
        JLabel courseworkLabel = new JLabel("@Safa Merchant Coursework");
        courseworkLabel.setHorizontalAlignment(SwingConstants.CENTER);
        courseworkLabel.setForeground(Color.LIGHT_GRAY);
        courseworkLabel.setBounds(20, 540, 184, 14);
        panel.add(courseworkLabel);
        
        JLabel DASHBOARD = new JLabel("DASHBOARD");
        DASHBOARD.setHorizontalAlignment(SwingConstants.CENTER);
        DASHBOARD.setForeground(Color.LIGHT_GRAY);
        DASHBOARD.setFont(new Font("Tahoma", Font.BOLD, 28));
        DASHBOARD.setBounds(10, 41, 207, 46);
        panel.add(DASHBOARD);
        
        JLabel lblNewLabel_1 = new JLabel("BASKET");
        lblNewLabel_1.setBorder(new LineBorder(new Color(255, 255, 255)));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setForeground(Color.WHITE);
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblNewLabel_1.setBounds(20, 252, 184, 46);
        panel.add(lblNewLabel_1);
        
        JToggleButton ProductsBtn = new JToggleButton("PRODUCTS");
        ProductsBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        ProductsBtn.setBackground(Color.WHITE);
        ProductsBtn.setBounds(20, 182, 184, 46);
        panel.add(ProductsBtn);
        
        JLabel lblNewLabel = new JLabel("YOUR BASKET");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setForeground(Color.WHITE);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 32));
        lblNewLabel.setBackground(new Color(29, 163, 139));
        lblNewLabel.setBounds(281, 18, 611, 58);
        contentPane.add(lblNewLabel);
        
        JToggleButton removeProduct = new JToggleButton("REMOVE PRODUCT");
        removeProduct.setFont(new Font("Tahoma", Font.BOLD, 16));
        removeProduct.setBackground(Color.WHITE);
        removeProduct.setBounds(237, 505, 227, 46);
        contentPane.add(removeProduct);
        
        final JTable finalTable1 = table;
        JToggleButton ClearAll = new JToggleButton("CLEAR BASKET");
        ClearAll.setFont(new Font("Tahoma", Font.BOLD, 16));
        ClearAll.setBackground(Color.WHITE);
        ClearAll.setBounds(497, 505, 227, 46);
        contentPane.add(ClearAll);
        
        ClearAll.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int option = JOptionPane.showConfirmDialog(BasketFrame.this, "Are you sure you want to clear your basket?", "Confirm Clear", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    // Loop through the basket to restore quantity to customer frame's table
                    for (ShopProduct product : basket) {
                        if (product instanceof Basket) {
                            Basket basketProduct = (Basket) product;
                            int barcode = basketProduct.getBarcode();
                            int quantity = basketProduct.getQuantityInStock();
                            
                            // Update quantity in customer frame's table
                            updateCustomerFrameTable(barcode, quantity);
                        }
                    }
                    
                    // Remove all rows from the table
                    model.setRowCount(0);

                    // Clear the basket list
                    basket.clear();

                    // Notify user
                    JOptionPane.showMessageDialog(BasketFrame.this, "Basket cleared successfully.");
                }
            }
        });

        
        JToggleButton CheckOutBtn = new JToggleButton("CHECKOUT");
        CheckOutBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        CheckOutBtn.setBackground(Color.WHITE);
        CheckOutBtn.setBounds(751, 505, 227, 46);
        contentPane.add(CheckOutBtn);
        
        CheckOutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	System.out.println(fullAddress);
                // Open PaymentFrame
            	if (basket.isEmpty()) {
            		JOptionPane.showMessageDialog(BasketFrame.this, "No items in the basket. ");
            	} else {
            	System.out.println(basket);
            	PaymentFrame paymentFrame = new PaymentFrame(basket,finalTable1, fullAddress);
                paymentFrame.setVisible(true);

                // Close BasketFrame
                dispose(); // Close the current frame
            	}
            }
        });

        ProductsBtn.addActionListener(e -> {
            setVisible(false); // Hide BasketFrame
            if (CustomerFrame.frame == null) {
                CustomerFrame.frame = new CustomerFrame(fullAddress);
            }
            CustomerFrame.frame.setVisible(true);
        });
        
        // Map to store total quantity for each barcode
        Map<Integer, Integer> quantityMap = new HashMap<>();

        // Loop through the basket to populate the table
        if (basket != null) {
            for (ShopProduct product : basket) {
                if (product instanceof Basket) {
                    Basket basketProduct = (Basket) product;
                    int barcode = basketProduct.getBarcode();
                    int quantity = basketProduct.getQuantityInStock();
                    
                    // Update quantity in the map
                    quantityMap.put(barcode, quantityMap.getOrDefault(barcode, 0) + quantity);
                }
            }
            
            
            
            // Add rows to the table using the quantityMap
            for (Map.Entry<Integer, Integer> entry : quantityMap.entrySet()) {
                int barcode = entry.getKey();
                int totalQuantity = entry.getValue();
                
                // Fetch the product details from the first instance of the barcode
                Basket firstInstance = null;
                for (ShopProduct product : basket) {
                    if (product instanceof Basket && product.getBarcode() == barcode) {
                        firstInstance = (Basket) product;
                        break;
                    }
                }
                
                // Add row to the table
                if (firstInstance != null) {
                    Object[] rowData = {
                            firstInstance.getBarcode(),
                            firstInstance.getCategory(),
                            firstInstance.getdeviceType(),
                            firstInstance.getBrand(),
                            firstInstance.getColor(),
                            firstInstance.getConnectivity(),
                            totalQuantity, // Use total quantity here
                            firstInstance.getRetailPrice(),
                            firstInstance.getAdditionalInfo()
                    };
                    model.addRow(rowData);
                }
            }
        }
        
        removeProduct.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = modelRowSelect(finalTable);
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(BasketFrame.this, "Please select a product to remove.");
                } else {
                    int barcode = (int) model.getValueAt(selectedRow, 0);
                    int quantity = (int) model.getValueAt(selectedRow, 6);

                    int option = JOptionPane.showConfirmDialog(BasketFrame.this, "Are you sure you want to delete this product?\n\n" + getProductDetails(selectedRow), "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                        if (quantity > 1) {
                            // Reduce quantity by one in the Basket object
                            Basket selectedBasket = Basket.selectBasketInstance(basket, barcode);
                            if (selectedBasket != null) {
                                selectedBasket.reduceQuantityByOne(barcode);
                            }
                            // Update the quantity in the table model
                            model.setValueAt(quantity - 1, selectedRow, 6);
                        } else {
                            // Delete the row
                            Basket selectedBasket = Basket.selectBasketInstance(basket, barcode);
                            if (selectedBasket != null) {
                                selectedBasket.deleteRowByBarcode(basket, barcode);
                            }
                            model.removeRow(selectedRow); // Also remove the row from the table model
                        }

                        updateCustomerFrameTable(barcode, 1); // Add one back to the table in CustomerFrame
                        updateStockFile(barcode, 1); // Adds one back to the Stock.txt as well

                        JOptionPane.showMessageDialog(BasketFrame.this, "Product removed successfully.");
                    }
                }
            }

            // Method to get product details from the selected row
            private String getProductDetails(int row) {
                StringBuilder details = new StringBuilder();
                details.append("Barcode: ").append(model.getValueAt(row, 0)).append("\n");
                details.append("Category: ").append(model.getValueAt(row, 1)).append("\n");
                details.append("Device Type: ").append(model.getValueAt(row, 2)).append("\n");
                details.append("Brand : ").append(model.getValueAt(row, 3)).append("\n");
                details.append("Color: ").append(model.getValueAt(row, 4)).append("\n");
                details.append("Connectivity: ").append(model.getValueAt(row, 5)).append("\n");
                details.append("Quantity: 1 ").append("\n");
                details.append("Retail Price: ").append(model.getValueAt(row, 7)).append("\n");
                details.append("Additional Info: ").append(model.getValueAt(row, 8)).append("\n");
                return details.toString();
            }

            private int modelRowSelect(JTable table) {
                int selectedRowInTable = table.getSelectedRow();
                if (selectedRowInTable != -1) {
                    return table.convertRowIndexToModel(selectedRowInTable);
                }
                return -1;
            }
        });
    }

    // Update quantity in the CustomerFrame's table
    private void updateCustomerFrameTable(int barcode, int quantity) {
        for (int i = 0; i < CustomerFrame.frame.model.getRowCount(); i++) {
            if ((int) CustomerFrame.frame.model.getValueAt(i, 0) == barcode) {
                // Update the quantity in the CustomerFrame's table
                CustomerFrame.frame.model.setValueAt((int) CustomerFrame.frame.model.getValueAt(i, 6) + quantity, i, 6);
                break;
            }
        }
    }
    
    private void restoreStockQuantity(List<ShopProduct> basket, JTable finalTable) {
        // Map to store total quantity for each barcode in the basket
        Map<Integer, Integer> basketQuantityMap = new HashMap<>();

        // Loop through the basket to populate the basketQuantityMap
        for (ShopProduct product : basket) {
            if (product instanceof Basket) {
                Basket basketProduct = (Basket) product;
                int barcode = basketProduct.getBarcode();
                int quantity = basketProduct.getQuantityInStock();

                // Update quantity in the map
                basketQuantityMap.put(barcode, basketQuantityMap.getOrDefault(barcode, 0) + quantity);
            }
        }

        // Get the table model from the provided table
        DefaultTableModel model = (DefaultTableModel) finalTable.getModel();

        // Loop through the table to update the quantity
        for (int row = 0; row < model.getRowCount(); row++) {
            int barcode = (int) model.getValueAt(row, 0);
            int quantity = basketQuantityMap.getOrDefault(barcode, 0);

            // Update the quantity in the table model
            model.setValueAt(quantity, row, 6);
        }
    }

   
    // Update the stock file
 // Update the stock file
    private void updateStockFile(int barcode, int quantity) {
        try {
            File file = new File("Stock.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder content = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (Integer.parseInt(parts[0].trim()) == barcode) {
                    // Update the quantity
                    parts[6] = String.valueOf(Integer.parseInt(parts[6].trim()) + quantity);
                }
                content.append(String.join(",", parts)).append("\n");
            }
            reader.close();

            // Write the updated content back to the file
            FileWriter writer = new FileWriter(file);
            writer.write(content.toString());
            writer.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}