import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.border.LineBorder;
import javax.swing.table.TableModel;
import java.util.Comparator;

public class CustomerFrame extends JFrame {

    private JPanel contentPane;
    private JTable table; //the table of Shop Product data
    protected DefaultTableModel model;
    private JTextField searchField;
    private List<Integer> selectedRows = new ArrayList<>();
    private List<ShopProduct> basket = new ArrayList<>();
    private TableRowSorter<TableModel> sorter; // TableRowSorter to filter rows
    private JLabel errorBarcodeLabel; // Declare the error label
    private JLabel errorMouseLabel; // Declare the error label
    private static String fullAddress;
    
 // Add a static instance variable to hold the single instance of CustomerFrame
    static CustomerFrame frame;
    private JTextField mouseSearchField;
    

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                if (frame == null) {
                    frame = new CustomerFrame(fullAddress);
                    frame.setVisible(true);
                    System.out.println(fullAddress);
                } else {
                    frame.setVisible(true);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public CustomerFrame(String fullAddress) {
//    	this.fullAddress = fullAddress; 
        setResizable(false);
        setBackground(new Color(29, 163, 139));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1039, 600);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(29, 163, 139));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        

        JLabel lblNewLabel = new JLabel("PRODUCTS");
        lblNewLabel.setBounds(225, 28, 711, 58);
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setBackground(new Color(128, 128, 0));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 32));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblNewLabel);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(235, 186, 782, 300);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        String[] columnHeaders = {"Barcode","Category", "Device Type", "Brand", "Color", "Connectivity", "Quantity", "Selling Price",  "Additional Info"};
        model = new DefaultTableModel(columnHeaders, 0);
        table.setModel(model);
        
//     // Set up the TableRowSorter for the table model
//        sorter = new TableRowSorter<>(model);
//        table.setRowSorter(sorter);
//
//        // Sort the table in ascending order of the retail price
//        Comparator<Double> priceComparator = new Comparator<Double>() {
//            @Override
//            public int compare(Double price1, Double price2) {
//                // Compare prices in ascending order
//                return Double.compare(price1, price2);
//            }
//        };
//        sorter.setComparator(7, priceComparator); // Set the comparator for the retail price column
//        sorter.setSortable(7, true); // Allow sorting for the retail price column
//        sorter.setSortKeys(Collections.singletonList(new RowSorter.SortKey(7, SortOrder.ASCENDING))); // Set the initial sort key for retail price column
//
//        
        JPanel searchPanel = new JPanel();
        searchPanel.setBounds(235, 111, 782, 64);
        searchPanel.setBackground(new Color(192, 192, 192));
        contentPane.add(searchPanel);
        searchPanel.setLayout(null);

        JLabel searchLabel = new JLabel("Search by Barcode:");
        searchLabel.setBounds(38, 9, 225, 14);
        searchPanel.add(searchLabel);

        searchField = new JTextField();
        searchField.setBounds(223, 6, 129, 20);
        searchPanel.add(searchField);
        searchField.setColumns(10);

        JButton searchButton = new JButton("Search");
        searchButton.setBounds(362, 5, 77, 23);
        searchPanel.add(searchButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(444, 5, 77, 23);
        searchPanel.add(clearButton);
        
        JLabel mouseSearchLabel = new JLabel("Number of Mouse clicks:");
        mouseSearchLabel.setBounds(38, 39, 232, 14);
        searchPanel.add(mouseSearchLabel);
        
        mouseSearchField = new JTextField();
        mouseSearchField.setColumns(10);
        mouseSearchField.setBounds(223, 36, 129, 20);
        searchPanel.add(mouseSearchField);
        
        JButton mouseSearchButton = new JButton("Search");
        mouseSearchButton.setBounds(362, 35, 77, 23);
        searchPanel.add(mouseSearchButton);
        
        JButton mouseClearBtn = new JButton("Clear");
        mouseClearBtn.setBounds(444, 35, 77, 23);
        searchPanel.add(mouseClearBtn);
        
     // Initialize the error barcode label
        errorBarcodeLabel = new JLabel("*Error: Barcode not found");
        errorBarcodeLabel.setForeground(new Color(170, 0, 85));
        errorBarcodeLabel.setBounds(543, 9, 190, 14);
        searchPanel.add(errorBarcodeLabel);
        errorBarcodeLabel.setVisible(false); // Initially hide the error label

        
     // Initialize the error mouse label
        errorMouseLabel = new JLabel("*Error: Mouse Click not found");
        errorMouseLabel.setForeground(new Color(170, 0, 85));
        errorMouseLabel.setBounds(543, 39, 183, 14);
        searchPanel.add(errorMouseLabel);
        errorMouseLabel.setVisible(false); // Initially hide the error label


        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 227, 577);
        panel.setBackground(new Color(0, 0, 0));
        contentPane.add(panel);
        panel.setLayout(null);

        JToggleButton BasketBtn = new JToggleButton("BASKET");
        BasketBtn.setBackground(new Color(255, 255, 255));
        BasketBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        BasketBtn.setBounds(20, 252, 184, 46);
        panel.add(BasketBtn);

        JToggleButton LogoutBtn = new JToggleButton("LOGOUT");
        LogoutBtn.setBackground(new Color(255, 255, 255));
        LogoutBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        LogoutBtn.setBounds(20, 332, 184, 46);
        panel.add(LogoutBtn);
        
      //Logout function:
        LogoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Show a confirmation dialog
                int option = JOptionPane.showConfirmDialog(CustomerFrame.this, "Are you sure you want to log out, basket will be cleared?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
                
                // Check the user's choice
                if (option == JOptionPane.YES_OPTION) {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            // Show the message dialog
                            JOptionPane.showMessageDialog(CustomerFrame.this, "Logged out successfully.", "Logout", JOptionPane.INFORMATION_MESSAGE);
                            basket.clear();
                            // Restart the application from MainFrame
                            MainFrame mainFrame = new MainFrame();
                            mainFrame.setVisible(true);
                            basketCleared();
                            // Close the current PaymentFrame
                            dispose();
                        }
                    });
                }
            }
        });

        JLabel courseworkLabel = new JLabel("@ Coursework");
        courseworkLabel.setHorizontalAlignment(SwingConstants.CENTER);
        courseworkLabel.setForeground(new Color(192, 192, 192));
        courseworkLabel.setBounds(20, 540, 184, 14);
        panel.add(courseworkLabel);

        JLabel DASHBOARD = new JLabel("DASHBOARD");
        DASHBOARD.setHorizontalAlignment(SwingConstants.CENTER);
        DASHBOARD.setFont(new Font("Tahoma", Font.BOLD, 28));
        DASHBOARD.setForeground(new Color(192, 192, 192));
        DASHBOARD.setBounds(10, 41, 207, 46);
        panel.add(DASHBOARD);

        JLabel PRODUCTS = new JLabel("PRODUCTS");
        PRODUCTS.setBorder(new LineBorder(new Color(255, 255, 255)));
        PRODUCTS.setFont(new Font("Tahoma", Font.BOLD, 16));
        PRODUCTS.setHorizontalAlignment(SwingConstants.CENTER);
        PRODUCTS.setForeground(new Color(255, 255, 255));
        PRODUCTS.setBounds(20, 182, 184, 46);
        panel.add(PRODUCTS);

        JButton addToBasketButton = new JButton("ADD TO BASKET");
        addToBasketButton.setBounds(488, 508, 184, 46);
        addToBasketButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        addToBasketButton.setBackground(Color.LIGHT_GRAY);
        contentPane.add(addToBasketButton);

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchProductByBarcode();
            }
        });
        
        mouseSearchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchProductByMouseClicks();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	if (!searchField.getText().isEmpty()) {
            	searchField.setText("");
                errorBarcodeLabel.setVisible(false);
                mouseSearchField.setText("");
                sorter.setRowFilter(null);
            	}
            }
        });
        
        mouseClearBtn.addActionListener(new ActionListener() {
        	 public void actionPerformed(ActionEvent e) {
        	        if (!mouseSearchField.getText().isEmpty()) {
        	            mouseSearchField.setText(""); // Clear the mouseSearchField
        	            errorMouseLabel.setVisible(false);
        	            sorter.setRowFilter(null);
        	        }
        	    }
        	});


        BasketBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	PaymentFrame paymentFrame = new PaymentFrame(basket,table, fullAddress);
                BasketFrame basketFrame = new BasketFrame(basket,table, fullAddress);
                basketFrame.setVisible(true);
                setVisible(false); // Hide CustomerFrame
            }
        });


        populateTable();

        BasketBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                BasketBtn.setBackground(Color.LIGHT_GRAY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                BasketBtn.setBackground(new Color(192, 192, 192));
            }
        });

        LogoutBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                LogoutBtn.setBackground(Color.LIGHT_GRAY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                LogoutBtn.setBackground(new Color(192, 192, 192));
            }
        });

        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                handleRowSelection();
            }
        });
        
        

        addToBasketButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!selectedRows.isEmpty()) {
                    for (int row : selectedRows) {
                        int barcode = (int) table.getValueAt(row, 0);
                        for (int i = 0; i < model.getRowCount(); i++) {
                            if ((int) model.getValueAt(i, 0) == barcode) {
                                int quantityInStock = (int) model.getValueAt(i, 6);
                                if (quantityInStock > 0) { // Check if the product is in stock
                                    ShopProduct product = createBasketRow(i);
                                    if (product != null) {
                                        product.addToBasket(basket);
                                        JOptionPane.showMessageDialog(CustomerFrame.this, "Product(s) added to basket.");
                                        quantityInStock--; // Decrement the quantity
                                        model.setValueAt(quantityInStock, i, 6); // Update the quantity in the table
                                        // Update the stock.txt file
                                        updateStockFile(i, quantityInStock);
                                        // Display updated quantity in the table cell
                                        table.setValueAt(quantityInStock, i, 6);
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(CustomerFrame.this, "Product is out of stock.");
                                }
                                break;
                            }
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(CustomerFrame.this, "Please select a product to add to the basket.");
                }
            }
        });



    }
    
    public void basketCleared() {
        for (ShopProduct product : basket) {
            Object[] rowData = {
                    product.getBarcode(),
                    product.getCategory(),
                    product.getdeviceType(),
                    product.getBrand(),
                    product.getColor(),
                    product.getConnectivity(),
                    product.getQuantityInStock(),
                    product.getRetailPrice(),
                    product.getAdditionalInfo()
            };
            model.addRow(rowData);
            // Append the product details to the Stock.txt file
            appendToStockFile(product);
        }
        basket.clear(); // Clear the basket after adding items back to the table
    }

    private void appendToStockFile(ShopProduct product) {
        try {
            File file = new File("Stock.txt");
            FileWriter writer = new FileWriter(file, true); // Append mode
            String line = product.toFileString(); // Assuming ShopProduct has a method to convert to file string
            writer.write(line + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private ShopProduct createBasketRow(int row) {
        int barcode = (int) model.getValueAt(row, 0);
        ProductCategory category = (ProductCategory) model.getValueAt(row, 1);
        DeviceType deviceType = (DeviceType) model.getValueAt(row, 2);
        String brand = (String) model.getValueAt(row, 3);
        String color = (String) model.getValueAt(row, 4);
        ConnectivityType connectivity = (ConnectivityType) model.getValueAt(row, 5);
        int quantityInStock = (int) model.getValueAt(row, 6);
        double originalCost = (double) model.getValueAt(row, 7);
        double retailPrice = (double) model.getValueAt(row, 7);
        String additionalInfo = (String) model.getValueAt(row, 8);

        return new Basket(barcode,category,deviceType, brand, color, connectivity, quantityInStock, originalCost, retailPrice,  additionalInfo);
    }
    
    
    private void populateTable() {
        List<ShopProduct> productList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("Stock.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                ShopProduct product = ShopProduct.createProduct(line);
                if (product != null) {
                    productList.add(product);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Sort the product list based on retail price in ascending order
        productList.sort(Comparator.comparingDouble(ShopProduct::getRetailPrice));

        // Add sorted products to the table model
        for (ShopProduct product : productList) {
            Object[] rowData = {
                    product.getBarcode(),
                    product.getCategory(),
                    product.getdeviceType(),
                    product.getBrand(),
                    product.getColor(),
                    product.getConnectivity(),
                    product.getQuantityInStock(),
                    product.getRetailPrice(),
                    product.getAdditionalInfo()
            };
            model.addRow(rowData);
        }
    }

    //Searching by the Barcode Functions:
    private void searchProductByBarcode() {
        String barcodeToSearch = searchField.getText().trim();
        if (!barcodeToSearch.isEmpty()) {
            RowFilter<TableModel, Object> filter = RowFilter.regexFilter(barcodeToSearch, 0);
            sorter.setRowFilter(filter);
            
            // Check if any rows are visible after applying the filter
            if (table.getRowCount() == 0 || table.getRowCount() == table.getSelectedRowCount()) {
                errorBarcodeLabel.setVisible(true); // Show the error label
            } else {
                errorBarcodeLabel.setVisible(false); // Hide the error label
            }
        } else {
            errorBarcodeLabel.setVisible(true); // Show the error label
        }
    }

  //Searching by the Mouse Clicks Functions:
    private void searchProductByMouseClicks() {
        String mouseClicksToSearch = mouseSearchField.getText().trim();
        if (!mouseClicksToSearch.isEmpty()) {
            RowFilter<TableModel, Object> filter = RowFilter.regexFilter(mouseClicksToSearch, model.getColumnCount() - 1);
            sorter.setRowFilter(filter);
            
            // Check if any rows are visible after applying the filter
            if (table.getRowCount() == 0 || table.getRowCount() == table.getSelectedRowCount()) {
                errorMouseLabel.setVisible(true); // Show the error label
            } else {
                errorMouseLabel.setVisible(false); // Hide the error label
            }
        } else {
            errorMouseLabel.setVisible(true); // Show the error label
        }
    }


    
    private void updateStockFile(int rowIndex, int newQuantity) {
        try {
            File file = new File("Stock.txt");
            if (!file.exists()) {
                throw new FileNotFoundException("Stock.txt not found");
            }

            // Read the lines of the file into a list
            List<String> lines = Files.readAllLines(file.toPath());

            // Update the line at the specified rowIndex
            String lineToUpdate = lines.get(rowIndex);
            String[] parts = lineToUpdate.split(",");
            parts[6] = String.valueOf(newQuantity);
            String updatedLine = String.join(",", parts);
            lines.set(rowIndex, updatedLine);

            // Write the updated lines back to the file
            Files.write(file.toPath(), lines, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            System.out.println("SAVED TO TXT");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void handleRowSelection() {
        selectedRows.clear();
        int[] rows = table.getSelectedRows();
        for (int row : rows) {
            selectedRows.add(row);
        }
    }
    

    public List<ShopProduct> getBasket() {
        return basket;
    }
    
    public JTable getCustomerTable() {
        return table; // Assuming 'table' is the reference to the customer table
    }
}