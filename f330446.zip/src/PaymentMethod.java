
public interface PaymentMethod {
	void setAmount(double amount);
    void setAddress(String address);
    double getAmount();
    String getAddress();
    //processPayment will be instantiated in the subclasses 
	String processPayment(String receiptDetail);
}
