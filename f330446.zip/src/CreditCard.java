import java.util.Date;

public class CreditCard implements PaymentMethod {
    private String cardNumber;
    private Date date;
    private double amount;
    private String address;

    public CreditCard(String cardNumber, double amount, Date date, String address) {
        this.cardNumber = cardNumber;
        this.date = date;
        this.amount = amount;
        this.address = address;
    }

    @Override
    public String processPayment(String receiptDetail) {
        return "CreditCard [Card Number=" + cardNumber + ", date=" + date +
                ", amount=" + amount + ", address=" + address + "]";
    }

    // Other methods
    // Getters and setters for email, date, etc.
    
    @Override
    public void setAmount(double amount) {
        this.amount = amount;
    }

    @Override
    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public double getAmount() {
        return amount;
    }

    @Override
    public String getAddress() {
        return address;
    }
}
