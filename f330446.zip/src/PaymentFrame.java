import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.text.DecimalFormat;

public class PaymentFrame extends JFrame {

    private JPanel contentPane;
    private DefaultTableModel model;
    private JTable basketTable;
    private List<ShopProduct> basket;
    private JTextField emailField;
    private JTextField cardNumberField;
    private JComboBox<String> paymentMethodComboBox;
    private JComboBox<Integer> dayComboBox;
    private JComboBox<String> monthComboBox;
    private JComboBox<Integer> yearComboBox;
    private static String fullAddress;
    private JTextField cvcField;
    private JLabel addressLabel_1;
    
    

 // Calculate total amount method
    private double calculateTotalAmount() {
        double amount = 0.0;

        // Iterate over each item in the basket
        for (ShopProduct product : basket) {
            if (product instanceof Basket) {
                Basket basketProduct = (Basket) product;
                int quantity = basketProduct.getQuantityInStock();
                double retailPrice = basketProduct.getRetailPrice();

                // Calculate the subtotal for the current item and add it to the total amount
                double subtotal = quantity * retailPrice;
                amount += subtotal;
            }
        }

        // Round the amount to 2 decimal places
        DecimalFormat df = new DecimalFormat("#.##");
        amount = Double.parseDouble(df.format(amount));

        return amount;
    }

    private void mergeDuplicateItems() {
        Map<Integer, Basket> basketMap = new HashMap<>();

        // Iterate over each item in the basket
        for (ShopProduct product : basket) {
            if (product instanceof Basket) {
                Basket basketProduct = (Basket) product;
                int barcode = basketProduct.getBarcode();

                // Check if the barcode already exists in the map
                if (basketMap.containsKey(barcode)) {
                    // If yes, merge quantities
                    Basket existingBasket = basketMap.get(barcode);
                    existingBasket.setQuantityInStock(existingBasket.getQuantityInStock() + basketProduct.getQuantityInStock());
                } else {
                    // If no, add the basket to the map
                    basketMap.put(barcode, basketProduct);
                }
            }
        }

        // Clear the current basket list
        basket.clear();

        // Add the merged baskets back to the basket list
        basket.addAll(basketMap.values());
    }

    public PaymentFrame(List<ShopProduct> basket, JTable table, String fullAddress) {
        this.basket = basket;
        this.fullAddress = fullAddress; 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 600);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(29, 163, 139));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(45, 101, 921, 224);
        contentPane.add(scrollPane);

        basketTable = new JTable();
        scrollPane.setViewportView(basketTable);

        String[] columnHeaders = {"Barcode", "Category", "Device Type", "Brand", "Color", "Connectivity", "Quantity", "Retail Price", "Additional Info"};
        model = new DefaultTableModel(columnHeaders, 0);
        basketTable.setModel(model);
        mergeDuplicateItems();

        // Populate basket table
        if (basket != null) {
            for (ShopProduct product : basket) {
                if (product instanceof Basket) {
                    Basket basketProduct = (Basket) product;
                    Object[] rowData = {
                            basketProduct.getBarcode(),
                            basketProduct.getCategory(),
                            basketProduct.getdeviceType(),
                            basketProduct.getBrand(),
                            basketProduct.getColor(),
                            basketProduct.getConnectivity(),
                            basketProduct.getQuantityInStock(),
                            basketProduct.getRetailPrice(),
                            basketProduct.getAdditionalInfo()
                    };
                    model.addRow(rowData);
                }
            }
        }
        
        

        String[] paymentMethods = {"PayPal", "Credit Card"};

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(192, 192, 192));
        panel.setBounds(45, 336, 921, 178);
        contentPane.add(panel);

        JLabel courseworkLabel = new JLabel("@Safa Merchant Coursework");
        courseworkLabel.setHorizontalAlignment(SwingConstants.CENTER);
        courseworkLabel.setForeground(Color.LIGHT_GRAY);
        courseworkLabel.setBounds(20, 540, 184, 14);
        panel.add(courseworkLabel);

        JLabel paymentMethodLabel = new JLabel("Payment Method:");
        paymentMethodLabel.setBounds(20, 57, 168, 30);
        panel.add(paymentMethodLabel);
        paymentMethodLabel.setForeground(new Color(0, 0, 0));
        paymentMethodLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        paymentMethodComboBox = new JComboBox<>(paymentMethods);
        paymentMethodComboBox.setBounds(159, 64, 241, 20);
        panel.add(paymentMethodComboBox);
        

        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setBounds(496, 57, 150, 30);
        panel.add(addressLabel);
        addressLabel.setForeground(new Color(0, 0, 0));
        addressLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));

     // Initialize the class member addressLabel and set its text
        addressLabel_1 = new JLabel(fullAddress);
        addressLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        addressLabel_1.setBounds(622, 64, 241, 20);
        panel.add(addressLabel_1);


        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(496, 115, 124, 30);
        panel.add(emailLabel);
        emailLabel.setForeground(new Color(0, 0, 0));
        emailLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));

        emailField = new JTextField();
        emailField.setBounds(622, 122, 241, 20);
        panel.add(emailField);
        emailField.setColumns(10);

        JLabel lblTotalAmount = new JLabel("Total Amount:");
        lblTotalAmount.setForeground(Color.BLACK);
        lblTotalAmount.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblTotalAmount.setBounds(20, 11, 150, 30);
        panel.add(lblTotalAmount);

        // Calculate the total amount
        double amount = calculateTotalAmount();
        JLabel totalAmountLabel = new JLabel("£" + amount); // Display total amount
        totalAmountLabel.setForeground(Color.BLACK);
        totalAmountLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        totalAmountLabel.setBounds(159, 11, 150, 30);
        panel.add(totalAmountLabel);

        JLabel cardNumberLabel = new JLabel("Card Number:");
        cardNumberLabel.setBounds(496, 115, 105, 30);
        panel.add(cardNumberLabel);
        cardNumberLabel.setForeground(new Color(0, 0, 0));
        cardNumberLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        cardNumberLabel.setVisible(false); // Initially hidden

        cardNumberField = new JTextField();
        cardNumberField.setBounds(622, 122, 113, 20);
        panel.add(cardNumberField);
        cardNumberField.setColumns(10);
        
        cvcField = new JTextField();
        cvcField.setBounds(795, 122, 68, 20);
        panel.add(cvcField);
        cvcField.setColumns(10);
        
        JLabel cvcLabel = new JLabel("CVC:");
        cvcLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        cvcLabel.setBounds(745, 119, 48, 22);
        panel.add(cvcLabel);
        
        //Show email if Paypal selected or card Number and Security number if Credit Card selected:
        
        paymentMethodComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedMethod = (String) paymentMethodComboBox.getSelectedItem();
                if (selectedMethod != null) {
                    if (selectedMethod.equals("PayPal")) {
                        // If PayPal is selected, show email field and label, hide card number field and label
                        emailLabel.setVisible(true);
                        emailField.setVisible(true);
                        cardNumberLabel.setVisible(false);
                        cardNumberField.setVisible(false);
                        cvcLabel.setVisible(false);
                        cvcField.setVisible(false);
                    } else if (selectedMethod.equals("Credit Card")) {
                        // If Credit Card is selected, show card number field and label, hide email field and label
                        cardNumberLabel.setVisible(true);
                        cardNumberField.setVisible(true);
                        cvcLabel.setVisible(true);
                        cvcField.setVisible(true);
                        emailLabel.setVisible(false);
                        emailField.setVisible(false);
                    }
                }
            }
        });

        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setForeground(new Color(0, 0, 0));
        dateLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        dateLabel.setBounds(20, 122, 150, 20);
        panel.add(dateLabel);

     // Add a JLabel for displaying the date
        JLabel dateValueLabel = new JLabel();
        dateValueLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));

        // Set the initial text of the date label to today's date
        DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy");
        Calendar cal = Calendar.getInstance();
        String todayDate = dateFormat.format(cal.getTime());
        dateValueLabel.setText(todayDate);

        // Set the bounds of the date label
        dateValueLabel.setBounds(159, 122, 260, 20);
        panel.add(dateValueLabel);

        
        

        JToggleButton LogoutBtn = new JToggleButton("LOGOUT");
        LogoutBtn.setBounds(840, 40, 126, 29);
        contentPane.add(LogoutBtn);
        LogoutBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        LogoutBtn.setBackground(Color.WHITE);
        
        //Logout function:
        LogoutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Show a confirmation dialog
                int option = JOptionPane.showConfirmDialog(PaymentFrame.this, "Are you sure you want to log out, basket will be cleared?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
                
                // Check the user's choice
                if (option == JOptionPane.YES_OPTION) {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            // Show the message dialog
                            JOptionPane.showMessageDialog(PaymentFrame.this, "Logged out successfully.", "Logout", JOptionPane.INFORMATION_MESSAGE);
                            basket.clear();
                            // Restart the application from MainFrame
                            MainFrame mainFrame = new MainFrame();
                            mainFrame.setVisible(true);
                            
                            // Close the current PaymentFrame
                            dispose();
                        }
                    });
                }
            }
        });


        JButton confirmPaymentButton = new JButton("Confirm Payment");
        confirmPaymentButton.setBounds(786, 525, 180, 29);
        contentPane.add(confirmPaymentButton);
        confirmPaymentButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        confirmPaymentButton.setBackground(Color.WHITE);
     // ActionListener for confirmPaymentButton
        confirmPaymentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedMethod = (String) paymentMethodComboBox.getSelectedItem();

                if (selectedMethod == null) {
                    JOptionPane.showMessageDialog(PaymentFrame.this, "Please select a payment method.", "Incomplete Fields", JOptionPane.WARNING_MESSAGE);
                } else if (selectedMethod.equals("PayPal") && emailField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(PaymentFrame.this, "Please enter your email address for PayPal payment.", "Incomplete Fields", JOptionPane.WARNING_MESSAGE);
                } else if (selectedMethod.equals("Credit Card") && (cardNumberField.getText().isEmpty() || cvcField.getText().isEmpty())) {
                    JOptionPane.showMessageDialog(PaymentFrame.this, "Please enter both card number and CVC for Credit Card payment.", "Incomplete Fields", JOptionPane.WARNING_MESSAGE);
                } else if (selectedMethod.equals("Credit Card") && (cardNumberField.getText().length() != 6 || cvcField.getText().length() != 3)) {
                    JOptionPane.showMessageDialog(PaymentFrame.this, "Card number must be 6 digits long and CVC must be 3 digits long for Credit Card payment.", "Invalid Fields", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Call receiptMessage method to handle receipt display and saving
                    receiptMessage();
                }
            }
        });


        JToggleButton tglbtnBackToBasket = new JToggleButton("Back to Basket");
        tglbtnBackToBasket.setFont(new Font("Tahoma", Font.BOLD, 16));
        tglbtnBackToBasket.setBackground(Color.WHITE);
        tglbtnBackToBasket.setBounds(45, 40, 180, 29);
        contentPane.add(tglbtnBackToBasket);
        
        tglbtnBackToBasket.addActionListener(new ActionListener(){;
        public void actionPerformed(ActionEvent e) {
            BasketFrame basketFrame = new BasketFrame(basket,table, fullAddress);
            basketFrame.setVisible(true);
            setVisible(false); // Hide CustomerFrame
        }
        });
        JLabel lblNewLabel = new JLabel("PAYMENT");
        lblNewLabel.setBounds(366, 18, 316, 58);
        contentPane.add(lblNewLabel);
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setForeground(Color.WHITE);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 32));
        lblNewLabel.setBackground(new Color(29, 163, 139));
    }
    
    private void receiptMessage() {
        // Generate receipt
        String receiptInfo = generateReceipt();

        // Display message dialog with receipt information and options
        int option = JOptionPane.showOptionDialog(PaymentFrame.this, receiptInfo, "Payment Receipt", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new Object[]{"Save", "Finish"}, "Save");

        if (option == JOptionPane.YES_OPTION) {
            // Save the receipt
            String receipt = generateReceipt();
            saveReceipt(receipt);
            // Go back to CustomerFrame and clear the basket
            SwingUtilities.invokeLater(new Runnable() {
            	public void run() {
                    CustomerFrame customerFrame = new CustomerFrame(fullAddress);
                    customerFrame.setVisible(true);
                    dispose(); // Close the current PaymentFrame
                
                }
            });
        } else if (option == JOptionPane.NO_OPTION) {
            // Go back to CustomerFrame and clear the basket without showing "Receipt saved" message
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    CustomerFrame customerFrame = new CustomerFrame(fullAddress);
                    customerFrame.setVisible(true);
                    dispose(); // Close the current PaymentFrame
                }
            });
        }
    }



 // Method to generate receipt
    private String generateReceipt() {
        StringBuilder receipt = new StringBuilder();
        receipt.append("Payment Receipt\n");
        receipt.append("--------------------------------\n");

        // Add basket items to the receipt
        receipt.append("Items in Basket:\n");
        for (ShopProduct product : basket) {
            if (product instanceof Basket) {
                Basket basketProduct = (Basket) product;
                receipt.append("Barcode: ").append(basketProduct.getBarcode()).append(" - ")
                        .append("Category: ").append(basketProduct.getCategory()).append(" - ")
                        .append("Quantity: ").append(basketProduct.getQuantityInStock()).append(" - ")
                        .append("Price: £").append(basketProduct.getRetailPrice()).append("\n");
            }
        }

        // Add payment details to the receipt
        receipt.append("--------------------------------\n");
        receipt.append("\nPayment Method: ").append(paymentMethodComboBox.getSelectedItem()).append("\n");
        receipt.append("Total Amount: £").append(calculateTotalAmount()).append("\n");

        // Append the date
        DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy");
        Calendar cal = Calendar.getInstance();
        String todayDate = dateFormat.format(cal.getTime());
        receipt.append("Date: ").append(todayDate).append("\n");

        receipt.append("Address: ").append(fullAddress).append("\n");
        if (paymentMethodComboBox.getSelectedItem().equals("Credit Card")) {
            receipt.append("Card Number: ").append(cardNumberField.getText()).append("\n");
        } else {
            receipt.append("Email: ").append(emailField.getText()).append("\n");
        }

        return receipt.toString();
    }

 // Method to save receipt to a text file
    private void saveReceipt(String receipt) {
        try {
            // Create a file chooser to select the destination file
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Save Receipt");
            int userSelection = fileChooser.showSaveDialog(PaymentFrame.this);
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                BufferedWriter writer = new BufferedWriter(new FileWriter(fileToSave));
                writer.write(receipt);
                writer.close();
                JOptionPane.showMessageDialog(PaymentFrame.this, "Receipt saved successfully.", "Receipt Saved", JOptionPane.INFORMATION_MESSAGE);
            } else if (userSelection == JFileChooser.CANCEL_OPTION || userSelection == JFileChooser.ERROR_OPTION) {
                receiptMessage();
                return;
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(PaymentFrame.this, "Error occurred while saving receipt.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
                                                                     
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    List<ShopProduct> basket = new ArrayList<>();
                    JTable table = new JTable(); // Create your JTable instance here
                    PaymentFrame frame = new PaymentFrame(basket, table, fullAddress);
                    frame.setVisible(true);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
