import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddEntryFrame extends JFrame {

    private JTextField barcodeField;
    private JTextField brandField;
    private JTextField colorField;
    private JComboBox<DeviceType> deviceTypeComboBox;
    private JComboBox<ConnectivityType> connectivityComboBox;
    private JComboBox<ProductCategory> categoryComboBox;
    private JTextField quantityField;
    private JTextField originalCostField;
    private JTextField retailPriceField;
    private JTextField additionalInfoField;
    private StockFrame stockFrame;

    public AddEntryFrame(StockFrame stockFrame) {
        this.stockFrame = stockFrame;
        setTitle("Add New Entry");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 500);
        JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new GridLayout(0, 2, 10, 10));

        JLabel lblBarcode = new JLabel("Barcode:");
        contentPane.add(lblBarcode);

        barcodeField = new JTextField();
        contentPane.add(barcodeField);
        barcodeField.setColumns(10);

        JLabel lblBrand = new JLabel("Brand:");
        contentPane.add(lblBrand);

        brandField = new JTextField();
        contentPane.add(brandField);
        brandField.setColumns(10);

        JLabel lblColor = new JLabel("Color:");
        contentPane.add(lblColor);

        colorField = new JTextField();
        contentPane.add(colorField);
        colorField.setColumns(10);

        JLabel lblDeviceType = new JLabel("Device Type:");
        contentPane.add(lblDeviceType);

        deviceTypeComboBox = new JComboBox<>(DeviceType.values());
        contentPane.add(deviceTypeComboBox);

        JLabel lblConnectivityType = new JLabel("Connectivity Type:");
        contentPane.add(lblConnectivityType);

        connectivityComboBox = new JComboBox<>(ConnectivityType.values());
        contentPane.add(connectivityComboBox);

        JLabel lblProductCategory = new JLabel("Product Category:");
        contentPane.add(lblProductCategory);

        categoryComboBox = new JComboBox<>(ProductCategory.values());
        contentPane.add(categoryComboBox);

        JLabel lblQuantity = new JLabel("Quantity:");
        contentPane.add(lblQuantity);

        quantityField = new JTextField();
        contentPane.add(quantityField);
        quantityField.setColumns(10);

        JLabel lblOriginalCost = new JLabel("Original Cost:");
        contentPane.add(lblOriginalCost);

        originalCostField = new JTextField();
        contentPane.add(originalCostField);
        originalCostField.setColumns(10);

        JLabel lblRetailPrice = new JLabel("Retail Price:");
        contentPane.add(lblRetailPrice);

        retailPriceField = new JTextField();
        contentPane.add(retailPriceField);
        retailPriceField.setColumns(10);

        JLabel lblAdditionalInfo = new JLabel("Additional Info:");
        contentPane.add(lblAdditionalInfo);

        additionalInfoField = new JTextField();
        contentPane.add(additionalInfoField);
        additionalInfoField.setColumns(10);

        JButton btnSave = new JButton("Save");
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveNewEntry();
            }
        });
        contentPane.add(btnSave);

        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        contentPane.add(btnCancel);
    }

    private void saveNewEntry() {
        try {
            int barcode = Integer.parseInt(barcodeField.getText());
            String brand = brandField.getText();
            String color = colorField.getText();
            DeviceType deviceType = (DeviceType) deviceTypeComboBox.getSelectedItem();
            ConnectivityType connectivityType = (ConnectivityType) connectivityComboBox.getSelectedItem();
            ProductCategory category = (ProductCategory) categoryComboBox.getSelectedItem();
            int quantity = Integer.parseInt(quantityField.getText());
            double originalCost = Double.parseDouble(originalCostField.getText());
            double retailPrice = Double.parseDouble(retailPriceField.getText());
            String additionalInfo = additionalInfoField.getText();

            // Validate input
            if (barcode <= 0 || brand.isEmpty() || color.isEmpty() || deviceType == null ||
                    connectivityType == null || category == null || quantity <= 0 || originalCost < 0 ||
                    retailPrice < 0 || additionalInfo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill out all fields correctly.");
                return;
            }

            // Additional validation based on product category
            if (category == ProductCategory.MOUSE) {
                // If category is MOUSE, additional info must be a number
                try {
                    Integer.parseInt(additionalInfo);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Additional info for MOUSE category must be a number.");
                    return;
                }
            } else if (category == ProductCategory.KEYBOARD) {
                // If category is KEYBOARD, additional info must be "uk" or "us"
                if (!additionalInfo.equalsIgnoreCase("UK") && !additionalInfo.equalsIgnoreCase("US")) {
                    JOptionPane.showMessageDialog(this, "Additional info for KEYBOARD category must be either 'uk' or 'us'.");
                    return;
                }
            }

            // Check if barcode already exists
            if (barcodeExists(barcode)) {
                JOptionPane.showMessageDialog(this, "Sorry, this barcode already exists.");
                return;
            }

            // Construct the entry array
            String[] entry = {
                    String.valueOf(barcode),
                    brand,
                    color,
                    deviceType.toString(),
                    connectivityType.toString(),
                    String.valueOf(quantity),
                    String.valueOf(originalCost),
                    String.valueOf(retailPrice),
                    category.toString(),
                    additionalInfo
            };

            // Add the entry to the StockFrame
            stockFrame.addNewEntry(entry);

            // Close the frame
            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input format. Please enter numbers for barcode, quantity, original cost, and retail price.");
        }
    }

    // Method to check if barcode already exists
    private boolean barcodeExists(int barcode) {
        // Read the stock file and check if barcode exists
        try (BufferedReader reader = new BufferedReader(new FileReader("Stock.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int existingBarcode = Integer.parseInt(parts[0].trim());
                if (existingBarcode == barcode) {
                    return true;
                }
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error while checking barcode existence.");
        }
        return false;
    }
}
