import java.util.List;
import java.util.Iterator;

public class Basket extends ShopProduct {
    public Basket(int barcode, ProductCategory category, DeviceType deviceType, String brand, String color, ConnectivityType connectivity,
            int quantityInStock, double originalCost, double retailPrice, String additionalInfo) {
        super(barcode, category, deviceType, brand, color, connectivity, quantityInStock, originalCost, retailPrice, additionalInfo);
        this.quantityInStock = 1;
    }

    @Override
    public void addToBasket(List<ShopProduct> basket) {
        basket.add(this);
    }

    // Method to delete a row by its barcode
    public void deleteRowByBarcode(List<ShopProduct> basket, int barcode) {
        Iterator<ShopProduct> iterator = basket.iterator();
        while (iterator.hasNext()) {
            ShopProduct product = iterator.next();
            if (product instanceof Basket && product.getBarcode() == barcode) {
                iterator.remove(); // Remove the product from the basket
                break;
            }
        }
    }

    // Method to reduce the quantity number by one by barcode
    public void reduceQuantityByOne(int barcode) {
        if (this.getBarcode() == barcode) {
            this.quantityInStock--; // Reduce the quantity by one
        }
    }

    // Method to select a Basket instance from the basket list based on the barcode
    public static Basket selectBasketInstance(List<ShopProduct> basket, int barcode) {
        for (ShopProduct product : basket) {
            if (product instanceof Basket && product.getBarcode() == barcode) {
                return (Basket) product;
            }
        }
        return null; // If no matching instance is found
    }
}
