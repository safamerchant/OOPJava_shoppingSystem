import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class User {
    private int userID;
    private String username;
    private String name;
    private int houseNo;
    private String postcode;
    private String city;
    private Role role;

    public User(int userID, String username, String name, int houseNo, String postcode, String city, Role role) {
        this.userID = userID;
        this.username = username;
        this.name = name;
        this.houseNo = houseNo;
        this.postcode = postcode;
        this.city = city;
        this.role = role;
    }

    // Getters and setters
    
    public static String getUserDetails(String targetUsername) {
        try (BufferedReader br = new BufferedReader(new FileReader("UserAccount.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 7 && parts[1].trim().equals(targetUsername)) {
                    return getRole(line); // Call getRole function and return the role
                    
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Return null if the user is not found
    }
    


    
    public static String getRole(String userDetails) {
        if (userDetails != null) {
            String[] parts = userDetails.split(",");
            if (parts.length == 7) {
                String role = parts[6].trim(); // Extract the role part
                if (role.equalsIgnoreCase("ADMIN") || role.equalsIgnoreCase("CUSTOMER")) {
                    return role;
                } else {
                    return "Invalid user role";
                }
            }
        }
        return null;
    }
    
    
 //To get the full address of the user 
    public static String getFullAddress(String targetUsername) {
        try (BufferedReader br = new BufferedReader(new FileReader("UserAccount.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 7 && parts[1].trim().equals(targetUsername)) {
                    int houseNo = Integer.parseInt(parts[3].trim());
                    String city = parts[5].trim();
                    String postcode = parts[4].trim();
                    return houseNo + ", " + city + ", " + postcode;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Return null if the user is not found or if an error occurs
    }

    
    
    
    // Sample usage
    public static void main(String[] args) {
    }
   


    @Override
    public String toString() {
        return "User{" +
                "userID=" + userID +
                ", username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", houseNo=" + houseNo +
                ", postcode='" + postcode + '\'' +
                ", city='" + city + '\'' +
                ", role=" + role +
                '}';
    }
}
