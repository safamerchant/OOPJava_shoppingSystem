
public enum ProductCategory {
	KEYBOARD,
	MOUSE,
}
