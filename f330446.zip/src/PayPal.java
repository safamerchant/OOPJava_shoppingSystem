import java.util.Date;

public class PayPal implements PaymentMethod {
    private String email;
    private Date date;
    private double amount;
    private String address;

    public PayPal(String email, double amount, Date date, String address) {
        this.email = email;
        this.amount = amount;
        this.date = date;
        this.address = address;
    }

    @Override
    public String processPayment(String receiptDetail) {
        return "PayPal [email=" + email + ", date=" + date +
                ", amount=" + amount + ", address=" + address + "]";
    }

    // Other methods
    // Getters and setters for email, date, etc.
    
    @Override
    public void setAmount(double amount) {
        this.amount = amount;
    }

    @Override
    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public double getAmount() {
        return amount;
    }

    @Override
    public String getAddress() {
        return address;
    }
}
