import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;


// Subclass of Product representing a stock product
public class StockProduct extends Product {
    // Additional attributes specific to StockProduct
	protected DeviceType deviceType;
    private String additionalInfo; // additionalInfo of the product in the stock

    // Constructor
    public StockProduct(int barcode,ProductCategory category, DeviceType deviceType, String brand, String color, ConnectivityType connectivity,
                        int quantityInStock, double originalCost, double retailPrice,  String additionalInfo) {
        super(barcode,category, brand, color, connectivity, quantityInStock, originalCost, retailPrice );
        this.deviceType = deviceType;
        this.additionalInfo = additionalInfo;

    }

    // Override toString method to include additionalInfo
    @Override
    public String toString() {
        return "Barcode: " + barcode + ", Category: " + category + ", DeviceType: "+ deviceType + category +", Brand: " + brand + ", Color: " + color + ", Connectivity: " + connectivity +
                ", Quantity in Stock: " + quantityInStock + ", Original Cost: $" + originalCost + ", Retail Price: $" + retailPrice +
                 ", Additional Info: " + additionalInfo;
    }
 // Method to create a StockProduct object from a line of text
    public static StockProduct createProduct(String line) {
	    try {
	        // Split the line into parts based on any number of consecutive spaces followed by a comma
	        String[] parts = line.split("\\s*,\\s*");

	        // Ensure there are enough parts to create a product
	        if (parts.length < 10) {
	            throw new IllegalArgumentException("Invalid data format: " + line);
	        }

	        // Extract data from the parts array
	        int barcode = Integer.parseInt(parts[0]);
	        ProductCategory category = ProductCategory.valueOf(parts[1].trim().toUpperCase());
	        DeviceType deviceType = DeviceType.valueOf(parts[2].trim().toUpperCase());
	        String brand = parts[3].trim();
	        String color = parts[4].trim();

	        // Handle connectivity type
	        String connectivityString = parts[5].trim().toUpperCase();
	        // If the connectivityString contains additional information, extract only the enum value part
	        if (connectivityString.contains(",")) {
	            connectivityString = connectivityString.split(",")[0];
	        }
	        ConnectivityType connectivity = ConnectivityType.valueOf(connectivityString);

	        int quantityInStock = Integer.parseInt(parts[6].trim());
	        if (quantityInStock <= 0) {
	            // If quantity is 0 or negative, return null
	            return null;
	        }

	        double originalCost = Double.parseDouble(parts[7].trim());
	        double retailPrice = Double.parseDouble(parts[8].trim());
	        String additionalInfo = parts[9].trim();

	        // Create an instance of the StockProduct class
	        return new StockProduct(barcode, category, deviceType, brand, color, connectivity, quantityInStock, originalCost, retailPrice, additionalInfo);

	    } catch (IllegalArgumentException | ArrayIndexOutOfBoundsException e) {
	        e.printStackTrace(); // Handle parsing errors
	        return null; // Return null if an exception occurs
	    }
	}


    // Method to read Stock.txt and create StockProduct objects
    public static void readStockFile(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Create a StockProduct object for each line
                StockProduct product = createProduct(line);
                if (product != null) {
                    // Do something with the product, like adding it to a list
                    System.out.println(product); // For demonstration, printing each product
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // Handle file IO errors
        }
    }

    //Main method to check implementation of class is done correctly
//    public static void main(String[] args) {
//        readStockFile("Stock.txt");
//    }

    // Getter and setter for additionalInfo
    public DeviceType getdeviceType() {
        return deviceType;
    }
    public void setdeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}