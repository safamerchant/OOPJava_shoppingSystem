import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
//import java.util.ArrayList;
//import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

// Subclass of Product representing a stock product
public class ShopProduct extends Product {
    // Additional attributes specific to ShopProduct
	protected DeviceType deviceType; // Type of connectivity
    private String additionalInfo; // AdditionalInfo of the product in the stock

    // Constructor
    public ShopProduct(int barcode,ProductCategory category, DeviceType deviceType, String brand, String color, ConnectivityType connectivity,
                        int quantityInStock, double originalCost, double retailPrice,  String additionalInfo) {
        super( barcode, category, brand, color, connectivity, quantityInStock,originalCost, retailPrice );
        this.deviceType = deviceType;
        this.additionalInfo = additionalInfo;

    }

	@Override
	public String toString() {
		return "[" + ", barcode=" + barcode +", category=" + category +"deviceType=" + deviceType + ", brand=" + brand +
				", color=" + color + ", connectivity=" + connectivity
				+ ", quantityInStock=" + quantityInStock + ", originalCost=" + originalCost + ", retailPrice="
				+ retailPrice + ", additionalInfo=" + additionalInfo +"]";
	}

	// Method to create a ShopProduct object from a line of text
	public static ShopProduct createProduct(String line) {
	    try {
	        // Split the line into parts based on any number of consecutive spaces followed by a comma
	        String[] parts = line.split("\\s*,\\s*");

	        // Ensure there are enough parts to create a product
	        if (parts.length < 10) {
	            throw new IllegalArgumentException("Invalid data format: " + line);
	        }

	        // Extract data from the parts array
	        int barcode = Integer.parseInt(parts[0]);
	        ProductCategory category = ProductCategory.valueOf(parts[1].trim().toUpperCase());
	        DeviceType deviceType = DeviceType.valueOf(parts[2].trim().toUpperCase());
	        String brand = parts[3].trim();
	        String color = parts[4].trim();

	        // Handle connectivity type
	        String connectivityString = parts[5].trim().toUpperCase();
	        // If the connectivityString contains additional information, extract only the enum value part
	        if (connectivityString.contains(",")) {
	            connectivityString = connectivityString.split(",")[0];
	        }
	        ConnectivityType connectivity = ConnectivityType.valueOf(connectivityString);

	        int quantityInStock = Integer.parseInt(parts[6].trim());
	        if (quantityInStock <= 0) {
	            // If quantity is 0 or negative, return null
	            return null;
	        }

	        double originalCost = Double.parseDouble(parts[7].trim());
	        double retailPrice = Double.parseDouble(parts[8].trim());
	        String additionalInfo = parts[9].trim();

	        // Create an instance of the ShopProduct class
	        return new ShopProduct(barcode, category, deviceType, brand, color, connectivity, quantityInStock, originalCost, retailPrice, additionalInfo);

	    } catch (IllegalArgumentException | ArrayIndexOutOfBoundsException e) {
	        e.printStackTrace(); // Handle parsing errors
	        return null; // Return null if an exception occurs
	    }
	}



    
    // Method to read Stock.txt and create ShopProduct objects
    public static void readStockFile(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Create a ShopProduct object for each line
                ShopProduct product = createProduct(line);
                if (product != null) {
                    // Do something with the product, like adding it to a list
                    System.out.println(product); // For demonstration, printing each product
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // Handle file IO errors
        }
    }
    
    // Add the toFileString() method
    public String toFileString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getBarcode()).append(","); // Append barcode
        sb.append(getCategory()).append(","); // Append category
        sb.append(getdeviceType()).append(","); // Append device type
        sb.append(getBrand()).append(","); // Append brand
        sb.append(getColor()).append(","); // Append color
        sb.append(getConnectivity()).append(","); // Append connectivity
        sb.append(getQuantityInStock()).append(","); // Append quantity in stock
        sb.append(getOriginalCost()).append(","); // Append original cost
        sb.append(getRetailPrice()).append(","); // Append retail price
        sb.append(getAdditionalInfo()); // Append additional info
        return sb.toString();
    }
    
    //Add method to search products by barcode: From the Customer Frame.

    //Main method to check implementation of class is done correctly
//    public static void main(String[] args) {
//        readStockFile("Stock.txt");
//    }

    // Getter and setter for additionalInfo
    public DeviceType getdeviceType() {
        return deviceType;
    }
    public void setdeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }
    
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
    public void addToBasket(List<ShopProduct> basket) {
        basket.add(this);
    }

}
